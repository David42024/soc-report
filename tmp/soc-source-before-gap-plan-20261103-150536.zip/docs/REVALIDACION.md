# Revalidación de SOC Report Router

**Fecha** 3 de noviembre de 2026. **Entorno** Windows y PowerShell. Se distingue evidencia del código, pruebas locales con SQLite o simulaciones y pruebas contra la pila integrada.

## Plataforma común obligatoria

| Característica | Estado | Evidencia |
| --- | --- | --- |
| React 18 | Cumple | Declarado y fijado en `frontend/package.json` y el archivo de bloqueo. |
| TypeScript | Cumple | El arranque ejecutó `tsc --noEmit` y Vite completó el build. |
| TailwindCSS | Cumple | Configurado en el frontend e incorporado al CSS compilado. |
| Recharts | Cumple | Dashboard con gráficos de distribución, carga, tendencia y SLA mensual. |
| FastAPI, SQLAlchemy y Pydantic | Cumple | API, sesiones y consultas parametrizadas, validación de cuerpos y filtros. |
| n8n en Docker | Cumple | Contenedor `soc-router-n8n-1`, con webhook y callbacks de asignación y aviso. |
| Langflow independiente | Cumple | Servicio Windows del proyecto en `127.0.0.1:7861` y consumo por API HTTP. La disponibilidad de los proveedores se evalúa aparte. |
| PostgreSQL 16 | Cumple | `SHOW server_version` devolvió PostgreSQL 16.15 en el contenedor dedicado. |
| Redis para caché | Cumple | `soc:metrics` usa vencimiento de cinco segundos. Aplica a `/api/metricas`. |
| Redis para colas | Cumple | Conjunto ordenado `soc:routing`. PostgreSQL conserva los pendientes para la recuperación. |
| Redis para sesiones y límites | Cumple | Sesiones con vencimiento y contadores por ventana. Las pruebas de plataforma ejercitan el Redis local. |
| JWT y RBAC propio | Cumple | JWT firmado, con expiración, sesión revocable y permisos en el servidor. |
| Administrador | Cumple | Gestión de usuarios, casos, reglas, equipos y auditoría. |
| Analista | Cumple | Atención, hitos, revisión humana, colaboración y exportaciones de casos. |
| Gestor | Cumple | Consulta, dashboard, exportaciones y creación de líneas base. |
| Auditor | Cumple | Auditoría y su exportación. La bitácora por ID de reporte también está autorizada. |
| `audit_log` y campos de identidad | Cumple | Tabla independiente de la bitácora de negocio, con usuario, rol, acción, módulo, IP y fecha. El resultado HTTP se registra en la salida. |
| Middleware de auditoría | Cumple | Intercepta `/api/` y `/internal/`. |
| Entrada y salida normal | Cumple | `entry` y `exit` correlacionados por `X-Request-ID`. |
| Entrada y salida de rechazos | Cumple | El rechazo autenticado con credencial inválida registra `entry`, `rejected` y `exit` para el mismo ID. La cobertura se refiere a las rutas del middleware. |
| Inmutabilidad | Cumple | Triggers que rechazan `UPDATE`, `DELETE` y `TRUNCATE`. |
| Cambios críticos | Cumple | Triggers para reportes, asignaciones, usuarios, bitácora, mediciones y tablas operativas nuevas. |
| PDF con WeasyPrint | Cumple | Generación en servidor y apertura mediante lector PDF. |
| Word con python-docx | Cumple | Generación y lectura de las tablas DOCX. |
| Excel con openpyxl | Cumple | Generación y lectura de hojas XLSX. |
| Generación independiente de Office | Cumple | Las tres exportaciones se generan mediante las bibliotecas de Python. |

## Indicadores e impacto

| Característica | Estado | Evidencia |
| --- | --- | --- |
| Configurar y medir SLA | Cumple | Plazos de respuesta y resolución versionados. El dashboard presenta cumplidos sobre casos evaluables. |
| Demostrar impacto operacional de SLA | No cumple | Existe un histórico DEMO. Falta una serie operativa representativa y un criterio de éxito acordado. |
| Medir ciclo, línea base y revisión humana | Cumple | Se guardan el tiempo de recepción a notificación, las muestras de línea base y el tiempo de revisión cuando se registra. |
| Calcular horas estimadas | Cumple | Estimación basada en tiempo manual medio menos ciclo automático y revisión humana. |
| Demostrar horas reales ahorradas | No cumple | PostgreSQL contiene una línea base DEMO y cero reales. El ahorro real requiere mediciones comparables de triaje manual y asistido. |

## Validación funcional ampliada

### 1. Flujo central

| Criterio | Estado | Evidencia |
| --- | --- | --- |
| Persistencia antes de n8n | Cumple | `db.save_report` confirma la transacción antes de `dispatch`. La prueba de corte consulta `reports` y confirma que todavía no hay asignación. |
| Salida estructurada de Langflow | Cumple | Tipo, severidad, activo y confianza validados con Pydantic. El caso integrado anterior conserva los cuatro campos en PostgreSQL. |
| Confianza inferior a 0,75, salida inválida e inyección | Cumple | El umbral inicial es 0,75 y admite configuración. Hay pruebas de los tres motivos. El caso malicioso integrado va a Triaje SOC sin entregar la instrucción a Langflow. |
| Respaldo Gemini cuando falla Groq | Parcial | Se activa para fallos de transporte, HTTP 408, 429 o 5xx. Groq y el respaldo forzado Gemini pasaron en Langflow real. Un error permanente de Groq, como HTTP 400, sigue enviando al caso a la contingencia de FastAPI. |
| Contingencia cuando el clasificador falla | Cumple | FastAPI conserva el reporte, marca `origen=fallback`, usa `otro` y severidad `media` y deriva al equipo de revisión. El enrutador aplica las reglas a esa clasificación de contingencia. |
| n8n asigna equipo, SLA y aviso | Cumple | Asignación y notificación registradas por el actor `n8n`. Los plazos se determinan por severidad y versión de reglas. |
| Idempotencia y conflicto | Cumple | Repetición de la clave y contenido devuelve el caso. Con contenido distinto responde 409. |
| Una asignación y una notificación | Cumple | Se comprueba por SQL y bitácora después de diez reenvíos. |
| Recuperación con n8n y Redis reiniciados | Cumple | Caso persistido durante el corte y recuperación automática al restaurar la pila. |
| Resistencia a la instrucción de prueba | Cumple | El patrón «ignora todas las instrucciones» se desvía a revisión. Es una comprobación específica de la detección básica. |

### 2. Usuarios, roles y perfiles

| Criterio | Estado | Evidencia |
| --- | --- | --- |
| Alta, lectura, actualización, cambio de rol, reset y desactivación | Cumple | `/api/users` limitado al administrador. La baja es lógica. |
| Al menos un administrador activo | Cumple | El backend bloquea degradar o desactivar al último administrador. |
| Matriz de los cuatro roles | Cumple | Sesiones de los cuatro roles y 67 comprobaciones HTTP de lectura y acciones protegidas. La visibilidad de la interfaz se contrastó con React y sus pruebas. |
| Invalidación al cambiar rol, contraseña o estado | Cumple | Incremento de versión de token, comprobado en autenticación. |
| Revocación al cerrar sesión | Cumple | Se elimina la sesión y el token deja de autorizar. |
| Perfil y cambio de contraseña | Cumple | Perfil de sesión y actualización con contraseña actual, con revocación. |
| Bloqueo por intentos fallidos | Cumple | Límite por IP y bloqueo por cuenta tras cinco fallos durante quince minutos. |
| Permisos granulares | Cumple | Matriz fija por rol y acción aplicada en API. |
| TOTP opcional | No cumple | El sistema actual carece de alta, verificación y recuperación TOTP. |

### 3. Bitácora y auditoría

| Criterio | Estado | Evidencia |
| --- | --- | --- |
| Login, logout y accesos rechazados | Cumple | Eventos explícitos de autenticación y triple registro correlacionado del 401. |
| Entrada y salida por navegación | Parcial | Registra `module_enter` y `module_exit` en transiciones autenticadas. La navegación pública y el cierre abrupto de pestaña quedan fuera de la garantía. |
| Resultado en cada fila | Parcial | La columna admite `NULL`. La entrada, las transiciones de navegación y los eventos de triggers pueden carecer de resultado HTTP. La salida correlacionada de API tiene el código. |
| Cuerpos y secretos fuera de la auditoría | Cumple | El middleware guarda metadatos, sin el cuerpo ni los encabezados de credenciales. |
| Bloqueos directos y triggers críticos | Cumple | PostgreSQL rechaza `UPDATE`, `DELETE` y `TRUNCATE` directos. La prueba de plataforma verifica `INSERT` y `UPDATE` de usuarios por trigger. |
| Filtros y exportación | Cumple | Usuario, rol, módulo, acción, fechas y estado HTTP. Desde la cuenta Auditor se abrieron PDF, DOCX y XLSX con las dos mismas filas del filtro aplicado. |
| Solo administrador y auditor | Cumple | Restricción en React y permisos en API. |

### 4. Dashboard

| Criterio | Estado | Evidencia |
| --- | --- | --- |
| Estado, tipo y severidad | Cumple | Tres distribuciones en el dashboard. |
| SLA y tiempos medios | Cumple | Respuesta y resolución a tiempo. Promedios y muestras para clasificación, primera respuesta y resolución. |
| Precisión con revisión humana | Cumple | Coincidencia de tipo, severidad y activo frente a la última revisión. Denominador explícito y separación DEMO. |
| Carga y tendencia | Cumple | Carga por equipo responsable y tendencia mensual. |
| Cuatro filtros | Cumple | Fecha de recepción en Lima, tipo, severidad y equipo. |
| Universo completo | Cumple | Consulta independiente del tablero limitado a 100. Prueba local con 102 filas. |
| Coincidencia con SQL independiente | Cumple | 37 casos globales y 18 con los cuatro filtros. Coincidieron los totales, DEMO, distribuciones, tiempos, SLA, carga, tendencia y revisión. |
| Identificación DEMO y estimaciones | Cumple | Se distingue la marca DEMO y el histórico sintético separado. Los totales generales incluyen los casos DEMO y muestran su cantidad. |

### 5. Reportes

| Criterio | Estado | Evidencia |
| --- | --- | --- |
| Tres informes operacionales | Cumple | Cola actual, vencimiento SLA y asignaciones pendientes. |
| Cuatro informes de gestión | Cumple | Cumplimiento mensual, tendencias, clasificador y carga por equipo. |
| Tres formatos por informe | Cumple | Se abrieron 42 archivos, las 21 combinaciones de siete informes y tres formatos con dos filtros. Una corrida inicial interrumpida por un HTTP 503 se repitió completa. |
| Exportación exclusiva de gestor y administrador | No cumple | Analista también puede exportar informes y reportes operativos. Auditor puede exportar auditoría y recibe 403 en informes de casos. |
| Exportaciones auditadas | Cumple | Las 42 descargas exitosas tuvieron salida HTTP 200 en `audit_log` para el mismo `X-Request-ID`. |

### 6. Módulos adicionales

| Criterio | Estado | Evidencia |
| --- | --- | --- |
| Catálogo de activos | Cumple | Alta, edición, consulta y marcado de inactividad. |
| Equipos y responsables | Cumple | Directorio con contacto, disponibilidad y casos abiertos por equipo. |
| Reglas y SLA editables, versionadas y auditadas | Cumple | UI Operaciones → Reglas y API de publicación. El JSON sigue como configuración inicial. |
| Cola y confirmación o corrección humana | Cumple | Cola dedicada y revisión persistida por reporte. |
| Configuración del umbral | Cumple | Se publica con la versión de reglas. |
| Comentarios y adjuntos | Cumple | Colaboración por reporte, con permisos, límite de tamaño y descarga forzada. |
| Centro de notificaciones | Cumple | Lista de avisos y marca de lectura por cuenta. |
| Salud de todos los servicios y proveedores | Parcial | El diagnóstico comprueba FastAPI, PostgreSQL, Redis, Langflow y n8n. Groq y Gemini se comprueban con pruebas de proveedor separadas. |

### 7. Seguridad

| Criterio | Estado | Evidencia |
| --- | --- | --- |
| Secretos fuera de fuentes y logs | Cumple en el alcance revisado | Se examinaron 72 archivos fuente y registros por coincidencia exacta de credenciales configuradas, con cero coincidencias. `.env` y `.venv` están en `.gitignore`. Esta carpeta carece de historial Git verificable. |
| Acceso directo con roles y sin token | Cumple en las rutas probadas | API directa devuelve 401 sin sesión y 403 con rol insuficiente. Formulario, chat, login y salud son públicos por diseño. |
| Límites en formulario y chat | Cumple | Ventanas de solicitudes configurables y pruebas locales de limitación. |
| Validación, adjuntos y CORS | Cumple | Pydantic, tamaño y cantidad de adjuntos, nombre validado y descarga forzada. El preflight de origen externo carece de `Access-Control-Allow-Origin`. |
| PBKDF2 y secretos independientes | Cumple | PBKDF2-HMAC-SHA256 con sal y 600 000 iteraciones. Operador, webhook e interno usan valores distintos. |
| Chat sin reportes privados ni secretos en el mensaje | Cumple por diseño | La API del chat recibe el historial del usuario y contexto fijo. Carece de herramientas de lectura de casos. Las credenciales se usan como autenticación del proveedor. El usuario puede escribir datos sensibles en el texto. |

### 8. Calidad y operación

| Criterio | Estado | Evidencia |
| --- | --- | --- |
| Suite local antes y después | Cumple | Línea base registrada y nueva corrida local de Python, reglas, build y React. |
| Suite con servicios reales | Cumple | `Test-Soc.ps1 -Live` terminó con código 0. Pasaron 14 pruebas reales en clasificación, plataforma, chat y recuperación, además de las 58 pruebas locales y la compilación. |
| Stop y arranque desde cero | Parcial | Stop detuvo FastAPI, Langflow y los tres contenedores. El primer arranque alcanzó el límite de espera de 360 segundos por Langflow. El proceso quedó iniciándose y la pila quedó operativa tras restablecerse la conexión. |
| Persistencia tras reiniciar | Cumple | Comprobación de un reporte preexistente en PostgreSQL tras el ciclo de arranque. |
| SQLite, demo y local | Cumple | Pruebas de la API en SQLite temporal, clasificación demo y enrutamiento local. |
| Respaldo antes de cada migración | Parcial | Hay respaldo documentado de la migración previa y copia verificada antes de la última extensión. El arranque no genera automáticamente una copia para cada posible cambio de esquema. |
| README actualizado | Cumple | Arranque, pruebas, endpoints, permisos, datos DEMO y alcance de salud documentados. |

## Características adicionadas

Se conservan los temas claro, oscuro y sistema, la interfaz bilingüe con preferencias persistentes, el tablero de tres columnas, y el chat flotante con contexto, proveedor visible y reintentos. También permanecen el umbral inicial de 0,75, la detección básica de inyección, el triaje de contingencia, la idempotencia con conflicto, el reintento manual y los hitos separados. Revocación, PBKDF2, protección del último administrador, bloqueo de `TRUNCATE`, paginación, modos de respaldo, scripts PowerShell, datos DEMO y suites local e integrada siguen disponibles. El dashboard completo y los módulos de la extensión se desglosan en esta lista.

## Evidencia reproducible

- Reporte de recuperación DEMO `40361e98-b04e-4f6c-842e-6ad04b1431f4`. PostgreSQL registró `phishing`, `media`, `correo corporativo`, confianza `0,90` y origen `langflow`. La bitácora mostró `recibido`, `clasificado`, `enrutamiento_pendiente`, `asignado` y `notificacion`, con actor `n8n` en los dos últimos.
- Tras reiniciar Redis se comprobó el cambio de su `run_id`. El reporte se recuperó automáticamente al restaurar n8n. Diez reenvíos obtuvieron HTTP 200 con el mismo ID y el cambio de contenido obtuvo 409.
- Los resultados operativos están en `tmp/soc-revalidacion-operativa-20261103.log`. La corrida local está en `.venv/soc-runtime/test-results/soc-tests-20261103-140255.log`. La corrida integrada está en `.venv/soc-runtime/test-results/soc-tests-20261103-145319.log`.

import importlib.util
import json
import sys
import unittest
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

import httpx
from pydantic import SecretStr


def load_cloud_component():
    # The app's venv does not include Langflow. Stub only its component and UI types.
    modules = {}
    for path, attributes in {
        "lfx.custom.custom_component.component": {"Component": SimpleNamespace},
        "lfx.io": dict.fromkeys(("MessageInput", "Output", "SecretStrInput", "StrInput"), SimpleNamespace),
        "lfx.schema.message": {"Message": SimpleNamespace},
        "lfx.utils.secrets": {"secret_value_to_str": lambda key: key.get_secret_value()},
    }.items():
        modules[path] = ModuleType(path)
        vars(modules[path]).update(attributes)
    source = Path(__file__).resolve().parents[1] / "integrations/langflow/cloud_classifier_model.py"
    spec = importlib.util.spec_from_file_location("soc_cloud_test_module", source)
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, modules):
        spec.loader.exec_module(module)
    return module.SocCloudModel


class CloudModelTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.model = load_cloud_component()(
            system_message=SimpleNamespace(text="Instrucciones de clasificación."),
            input_value=SimpleNamespace(text="Reporte ficticio."),
            groq_model="openai/gpt-oss-20b",
            gemini_model="gemini-3-flash-preview",
            groq_api_key=SecretStr("test-groq"),
            gemini_api_key=SecretStr("test-gemini"),
        )
        self.hosts = []

    async def run_model(self, groq, gemini=None):
        client_type = httpx.AsyncClient

        def handle(request):
            host = request.url.host
            self.hosts.append(host)
            body = json.loads(request.content)
            if host == "api.groq.com":
                self.assertEqual(request.url.path, "/openai/v1/chat/completions")
                self.assertEqual(request.headers["Authorization"], "Bearer test-groq")
                self.assertEqual(body["model"], self.model.groq_model)
                self.assertEqual(body["messages"], [
                    {"role": "system", "content": "Instrucciones de clasificación."},
                    {"role": "user", "content": "Reporte ficticio."},
                ])
                self.assertTrue(body["response_format"]["json_schema"]["strict"])
                return groq(request) if callable(groq) else groq
            self.assertEqual(host, "generativelanguage.googleapis.com")
            self.assertEqual(request.url.path, f"/v1beta/models/{self.model.gemini_model}:generateContent")
            self.assertEqual(request.headers["x-goog-api-key"], "test-gemini")
            self.assertEqual(body["contents"][0]["parts"][0]["text"], "Reporte ficticio.")
            self.assertEqual(body["systemInstruction"]["parts"][0]["text"], "Instrucciones de clasificación.")
            self.assertEqual(body["generationConfig"]["responseMimeType"], "application/json")
            self.assertFalse(body["generationConfig"]["responseJsonSchema"]["additionalProperties"])
            self.assertIsNotNone(gemini, "Gemini no debía recibir esta solicitud")
            return gemini(request) if callable(gemini) else gemini

        with patch.object(httpx, "AsyncClient", side_effect=lambda **kwargs: client_type(
            transport=httpx.MockTransport(handle), **kwargs
        )):
            return await self.model.classify()

    async def test_primary_success_does_not_send_the_report_to_gemini(self):
        result = await self.run_model(httpx.Response(200, json={"choices": [{"message": {"content": "{}"}}]}))
        self.assertEqual((result.text, self.model.status, self.hosts), ("{}", "Groq", ["api.groq.com"]))

    async def test_transient_errors_use_gemini_and_ignore_thought_parts(self):
        def timed_out(request):
            raise httpx.ReadTimeout("simulated", request=request)

        for failure in (httpx.Response(408), httpx.Response(429), httpx.Response(500), httpx.Response(503), timed_out):
            with self.subTest(failure=failure):
                self.hosts.clear()
                gemini = httpx.Response(200, json={"candidates": [{"content": {"parts": [
                    {"thought": True, "text": "internal"}, {"text": "{"}, {"text": "}"},
                ]}}]})
                result = await self.run_model(failure, gemini)
                self.assertEqual((result.text, self.model.status), ("{}", "Gemini"))
                self.assertEqual(self.hosts, ["api.groq.com", "generativelanguage.googleapis.com"])

    async def test_primary_rejects_permanent_errors_and_bad_payloads(self):
        for status in (400, 401, 403, 404):
            with self.subTest(status=status), self.assertRaisesRegex(ValueError, f"Groq.*HTTP {status}"):
                await self.run_model(httpx.Response(status))
        for payload in ({}, {"choices": []}, {"choices": [{"message": {"content": " "}}]}):
            with self.subTest(payload=payload), self.assertRaisesRegex(ValueError, "respuesta"):
                await self.run_model(httpx.Response(200, json=payload))
        self.assertTrue(all(host == "api.groq.com" for host in self.hosts))

    async def test_gemini_failure_is_sanitized(self):
        def offline(request):
            raise httpx.ConnectError("synthetic secret in upstream error", request=request)

        for response, reason in (
            (httpx.Response(503, text="upstream payload"), "Gemini.*HTTP 503"),
            (offline, "Gemini no respondió"),
            (httpx.Response(200, json={"candidates": []}), "respuesta inválida"),
            (httpx.Response(200, json={"candidates": [{"content": {"parts": []}}]}), "respuesta vacía"),
        ):
            with self.subTest(reason=reason), self.assertRaisesRegex(ValueError, reason):
                await self.run_model(httpx.Response(429), response)

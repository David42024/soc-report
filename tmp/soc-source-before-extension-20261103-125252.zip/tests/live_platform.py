"""Opt-in checks against the local production stack, using disposable test identities."""
import json
import unittest
from io import BytesIO
from uuid import uuid4

import httpx
import psycopg
from redis import Redis
from openpyxl import load_workbook
from docx import Document
from dotenv import dotenv_values

from backend.config import ROOT


class LivePlatformTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.config = dotenv_values(ROOT / ".env")
        cls.accounts = json.loads((ROOT / ".venv/soc-runtime/access.json").read_text(encoding="utf-8"))
        cls.api = httpx.Client(base_url="http://127.0.0.1:8000", timeout=90, trust_env=False)
        cls.tokens = {}
        for account in cls.accounts:
            result = cls.api.post("/api/auth/login", json={key: account[key] for key in ("username", "password")}).raise_for_status().json()
            cls.tokens[account["role"]] = {"Authorization": "Bearer " + result["access_token"]}

    @classmethod
    def tearDownClass(cls):
        for headers in cls.tokens.values():
            cls.api.post("/api/auth/logout", headers=headers)
        cls.api.close()

    def test_database_version_redis_cache_and_session(self):
        with psycopg.connect(self.config["DATABASE_URL"], connect_timeout=5) as db:
            self.assertTrue(db.execute("SHOW server_version").fetchone()[0].startswith("16."))
        redis = Redis.from_url(self.config["REDIS_URL"])
        self.assertTrue(redis.ping())
        self.api.get("/api/metricas", headers=self.tokens["administrador"]).raise_for_status()
        self.assertTrue(redis.exists("soc:metrics"))
        self.assertTrue(list(redis.scan_iter("soc:session:*", count=100)))

    def test_all_roles_and_three_real_exports(self):
        for role, headers in self.tokens.items():
            with self.subTest(role=role):
                self.assertEqual(self.api.get("/api/reportes", headers=headers).status_code, 403 if role == "auditor" else 200)
                self.assertEqual(self.api.get("/api/audit", headers=headers).status_code, 200 if role in ("auditor", "administrador") else 403)
                self.assertEqual(self.api.get("/api/users", headers=headers).status_code, 200 if role == "administrador" else 403)
        manager = self.tokens["gestor"]
        pdf = self.api.get("/api/exportar/pdf", headers=manager).raise_for_status()
        self.assertTrue(pdf.content.startswith(b"%PDF-"))
        self.assertTrue(Document(BytesIO(self.api.get("/api/exportar/docx", headers=manager).raise_for_status().content)).paragraphs)
        workbook = load_workbook(BytesIO(self.api.get("/api/exportar/xlsx", headers=manager).raise_for_status().content))
        self.assertGreater(workbook["Reportes"].max_row, 1)

    def test_immutable_log_and_postgresql_change_triggers(self):
        admin = self.tokens["administrador"]
        username = "test_" + uuid4().hex[:12]
        user = self.api.post("/api/users", headers=admin, json={
            "username": username, "password": uuid4().hex + uuid4().hex, "role": "analista",
        }).raise_for_status().json()
        self.api.put(f"/api/users/{user['id']}", headers=admin, json={"role": "analista", "active": False}).raise_for_status()
        with psycopg.connect(self.config["DATABASE_URL"], connect_timeout=5) as db:
            rows = db.execute("SELECT action FROM audit_log WHERE entity_id=%s AND module='users'", (user["id"],)).fetchall()
            self.assertIn(("INSERT",), rows)
            self.assertIn(("UPDATE",), rows)
        for statement in ("UPDATE audit_log SET action='alterado'", "DELETE FROM audit_log", "TRUNCATE audit_log"):
            with psycopg.connect(self.config["DATABASE_URL"], connect_timeout=5) as db:
                with self.assertRaises(psycopg.Error):
                    db.execute(statement)
                db.rollback()

    def test_demo_baseline_is_identified(self):
        value = self.api.get("/api/triage", headers=self.tokens["gestor"]).raise_for_status().json()
        self.assertGreater(value["measured_reports"], 0)
        self.assertIsNotNone(value["baseline"])
        self.assertEqual(value["baseline"]["is_demo"], 1)
        self.assertGreater(value["demo_comparisons"], 0)
        self.assertEqual(len(json.loads(value["baseline"]["samples_json"])), 5)

    def test_rejected_requests_have_entry_and_exit_with_the_same_request_id(self):
        response = self.api.get("/api/auth/me", headers={"Authorization": "Bearer invalid-live-check"})
        self.assertEqual(response.status_code, 401)
        request_id = response.headers["X-Request-ID"]
        with psycopg.connect(self.config["DATABASE_URL"], connect_timeout=5) as db:
            rows = db.execute(
                "SELECT phase,status_code FROM audit_log WHERE request_id=%s ORDER BY occurred_at", (request_id,),
            ).fetchall()
        self.assertEqual([row[0] for row in rows], ["entry","rejected","exit"])
        self.assertEqual(rows[-1][1], 401)

    def test_historical_demo_is_explicit_and_uses_separate_aggregate_data(self):
        headers = self.tokens["gestor"]
        before = self.api.get("/api/metricas", headers=headers).raise_for_status().json()["total"]
        value = self.api.get("/api/impacto", headers=headers).raise_for_status().json()
        self.assertTrue(value["is_demo"])
        self.assertEqual(value["source"], "demo")
        self.assertGreaterEqual(len(value["periods"]), 6)
        self.assertEqual([row["period"] for row in value["periods"]], sorted(row["period"] for row in value["periods"]))
        first,last = value["periods"][0],value["periods"][-1]
        self.assertEqual((first["response_pct"],last["response_pct"]),(55,95))
        self.assertAlmostEqual(last["estimated_hours_saved"],40*(900-120-30)/3600)
        self.assertEqual(self.api.get("/api/metricas", headers=headers).raise_for_status().json()["total"],before)

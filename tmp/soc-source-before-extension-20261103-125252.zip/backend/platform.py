"""Role-restricted administration, compliance audit, baselines and exports."""
from typing import Literal
import json
from uuid import UUID, uuid4

from fastapi import Depends, HTTPException, Query, Request, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy.exc import IntegrityError

from .context import identity
from .db import utc_now
from .exports import export_report
from .security import LoginInput, hash_password

Role = Literal["administrador", "analista", "gestor", "auditor"]


class UserInput(LoginInput):
    password: str = Field(min_length=12, max_length=128)
    role: Role


class UserUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    role: Role
    active: bool
    password: str | None = Field(default=None, min_length=12, max_length=128)


class BaselineInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    label: str = Field(min_length=5, max_length=150)
    seconds: list[float] = Field(min_length=3, max_length=1000)
    is_demo: bool = False

    @field_validator("seconds")
    @classmethod
    def positive_samples(cls, values):
        import math
        if any(not math.isfinite(value) or value <= 0 or value > 86400 for value in values):
            raise ValueError("Cada muestra debe estar entre 0 y 86400 segundos.")
        return values


class ReviewInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    seconds: float = Field(ge=0, le=86400, allow_inf_nan=False)


def install_platform_routes(app, db, security):
    @app.post("/api/auth/login")
    def login(payload: LoginInput, request: Request):
        return security.login(payload, request)

    @app.get("/api/auth/me")
    def me(principal=Depends(security.authenticate)):
        return security.public_user(principal)

    @app.post("/api/auth/logout", status_code=204)
    def logout(principal=Depends(security.authenticate)):
        security.logout(principal)

    @app.get("/api/users", dependencies=[Depends(security.require("manage"))])
    def users():
        with db.session() as execute:
            return [dict(row) for row in execute("SELECT id,username,role,active,creado_at FROM users ORDER BY username").fetchall()]

    @app.post("/api/users", status_code=201, dependencies=[Depends(security.require("manage"))])
    def create_user(payload: UserInput):
        user_id = str(uuid4())
        try:
            with db.session(write=True) as execute:
                execute("""INSERT INTO users (id,username,password_hash,role,creado_at)
                    VALUES (%s,%s,%s,%s,%s)""",
                    (user_id, payload.username.lower(), hash_password(payload.password), payload.role, utc_now()))
        except IntegrityError:
            raise HTTPException(409, "El usuario ya existe.") from None
        return security.public_user(security.user(user_id=user_id))

    @app.put("/api/users/{user_id}", dependencies=[Depends(security.require("manage"))])
    def update_user(user_id: UUID, payload: UserUpdate):
        with db.session(write=True) as execute:
            if db.url:
                execute("LOCK TABLE users IN SHARE ROW EXCLUSIVE MODE")
            admins = execute("SELECT id FROM users WHERE role='administrador' AND active=1" + (" FOR UPDATE" if db.url else "")).fetchall()
            row = execute("SELECT * FROM users WHERE id=%s", (str(user_id),)).fetchone()
            if not row:
                raise HTTPException(404, "Usuario no encontrado.")
            if row["role"] == "administrador" and row["active"] and len(admins) == 1 and (not payload.active or payload.role != "administrador"):
                raise HTTPException(409, "Debe permanecer al menos un administrador activo.")
            password = hash_password(payload.password) if payload.password else row["password_hash"]
            execute("""UPDATE users SET role=%s,active=%s,password_hash=%s,token_version=token_version+1
                WHERE id=%s""", (payload.role, int(payload.active), password, str(user_id)))
        return security.public_user(security.user(user_id=str(user_id)))

    @app.get("/api/audit", dependencies=[Depends(security.require("audit"))])
    def audit_log(limit: int = Query(100, ge=1, le=500), before: UUID | None = None):
        return db.audit_records(limit, str(before) if before else None)

    @app.get("/api/triage", dependencies=[Depends(security.require("read"))])
    def triage():
        return db.triage_metrics()

    @app.get("/api/impacto", dependencies=[Depends(security.require("read"))])
    def impact():
        return db.impact_history()

    @app.post("/api/triage/baselines", status_code=201)
    def baseline(payload: BaselineInput, principal=Depends(security.require("baseline"))):
        baseline_id = str(uuid4())
        with db.session(write=True) as execute:
            execute("""INSERT INTO triage_baselines
                (id,label,sample_count,average_seconds,is_demo,created_by,created_at,samples_json)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
                (baseline_id, payload.label, len(payload.seconds), sum(payload.seconds) / len(payload.seconds),
                 int(payload.is_demo), principal["id"], utc_now(), json.dumps(payload.seconds)))
        return {"id": baseline_id}

    @app.post("/api/reportes/{report_id}/triaje", dependencies=[Depends(security.require("write"))])
    def review_time(report_id: UUID, payload: ReviewInput):
        with db.session(write=True) as execute:
            saved = execute("""UPDATE triage_measurements SET review_seconds=%s WHERE report_id=%s
                AND EXISTS (SELECT 1 FROM reports WHERE id=%s AND motivo_revision IS NOT NULL)
                RETURNING report_id""", (payload.seconds, str(report_id), str(report_id))).fetchone()
        if not saved:
            raise HTTPException(409, "El reporte debe estar notificado y requerir revisión.")
        return {"report_id": str(report_id), "review_seconds": payload.seconds}

    @app.get("/api/exportar/{format_name}", dependencies=[Depends(security.require("read"))])
    def export(format_name: Literal["pdf", "docx", "xlsx"]):
        content, media = export_report(db.all_reports(), db.metrics(), format_name)
        return Response(content, media_type=media,
            headers={"Content-Disposition": f'attachment; filename="soc-reportes.{format_name}"', "Cache-Control": "no-store"})

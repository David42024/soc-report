from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from uuid import uuid4

from sqlalchemy import create_engine, event, inspect, text
from sqlalchemy.engine import make_url

from .config import ROOT
from .context import identity


REPORTS = """
SELECT r.*, a.responsable, a.asignado_at, a.vence_respuesta_at,
       a.vence_resolucion_at, a.respondido_at, a.resuelto_at,
       n.ocurrido_at AS notificado_at
FROM reports r
LEFT JOIN assignments a ON a.report_id = r.id
LEFT JOIN bitacora n ON n.report_id = r.id AND n.accion = 'notificacion'
"""


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def deadline(received, minutes):
    start = datetime.fromisoformat(received) if isinstance(received, str) else received
    return (start + timedelta(minutes=minutes)).astimezone(timezone.utc).isoformat(
        timespec="microseconds"
    )


class Database:
    def __init__(self, settings):
        self.url = settings.database_url
        self.path = settings.sqlite_path
        url = make_url(self.url).set(drivername="postgresql+psycopg") if self.url else f"sqlite:///{self.path}"
        args = {"connect_timeout": 5} if self.url else {"timeout": 10, "check_same_thread": False}
        self.engine = create_engine(url, connect_args=args, pool_pre_ping=True)
        if not self.url:
            @event.listens_for(self.engine, "connect")
            def sqlite_foreign_keys(connection, record):
                connection.execute("PRAGMA foreign_keys = ON")

    @contextmanager
    def session(self, *, write=False):
        with self.engine.connect() as connection:
            def execute(query, params=()):
                pieces = query.split("%s")
                statement = pieces[0] + "".join(f":p{i}" + part for i, part in enumerate(pieces[1:]))
                return connection.execute(text(statement), {f"p{i}": value for i, value in enumerate(params)}).mappings()

            try:
                if write and not self.url:
                    connection.exec_driver_sql("BEGIN IMMEDIATE")
                actor = identity.get() or {}
                if self.url:
                    execute("SELECT set_config('soc.user_id', %s, true), set_config('soc.role', %s, true), set_config('soc.ip', %s, true), set_config('soc.request_id', %s, true)",
                            (actor.get("id", "sistema"), actor.get("role", "sistema"), actor.get("ip", ""), actor.get("request_id") or ""))
                yield execute
                connection.commit()
            except Exception:
                connection.rollback()
                raise

    def initialize(self):
        schema = (ROOT / "db" / "schema.sql").read_text(encoding="utf-8")
        with self.session(write=True) as execute:
            for statement in schema.split(";"):
                if statement.strip():
                    execute(statement)
        columns = {column["name"] for column in inspect(self.engine).get_columns("triage_baselines")}
        if "samples_json" not in columns:
            with self.session(write=True) as execute:
                execute("ALTER TABLE triage_baselines ADD COLUMN samples_json TEXT NOT NULL DEFAULT '[]'")
        audit_columns = {column["name"] for column in inspect(self.engine).get_columns("audit_log")}
        with self.session(write=True) as execute:
            if "request_id" not in audit_columns:
                execute("ALTER TABLE audit_log ADD COLUMN request_id TEXT")
            execute("CREATE INDEX IF NOT EXISTS audit_request_idx ON audit_log (request_id)")
        self.install_audit_triggers()

    def report(self, report_id):
        with self.session() as execute:
            row = execute(REPORTS + " WHERE r.id = %s", (report_id,)).fetchone()
            return dict(row) if row else None

    def reports(self):
        with self.session() as execute:
            return [
                dict(row) for row in execute(
                    REPORTS + " ORDER BY r.recibido_at DESC, r.id LIMIT 100"
                ).fetchall()
            ]

    def audit(self, report_id):
        with self.session() as execute:
            return [
                dict(row) for row in execute(
                    """SELECT accion, actor, ocurrido_at, detalle FROM bitacora
                       WHERE report_id = %s
                       ORDER BY ocurrido_at, CASE accion
                           WHEN 'recibido' THEN 1
                           WHEN 'clasificado' THEN 2
                           WHEN 'enrutamiento_pendiente' THEN 3
                           WHEN 'asignado' THEN 4
                           WHEN 'notificacion' THEN 5
                           WHEN 'responder' THEN 6
                           WHEN 'resolver' THEN 7
                       END, accion""", (report_id,)
                ).fetchall()
            ]

    @staticmethod
    def event(execute, report_id, action, actor, details):
        execute(
            """INSERT INTO bitacora (report_id, accion, actor, ocurrido_at, detalle)
               VALUES (%s, %s, %s, %s, %s) ON CONFLICT (report_id, accion) DO NOTHING""",
            (report_id, action, actor, utc_now(), details),
        )

    def save_report(self, report_id, payload, result, origin, reason, received_at):
        with self.session(write=True) as execute:
            row = execute(
                """INSERT INTO reports (
                    id, titulo, descripcion, tipo, severidad, activo_afectado, confianza,
                    origen, motivo_revision, recibido_at, clasificado_at
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO NOTHING RETURNING id""",
                (report_id, payload.titulo, payload.descripcion, result.tipo, result.severidad,
                 result.activo_afectado, result.confianza, origin, reason, received_at, utc_now()),
            ).fetchone()
            if row:
                self.event(execute, report_id, "recibido", "formulario", "Reporte registrado.")
                self.event(
                    execute, report_id, "clasificado", origin,
                    f"{result.tipo} / {result.severidad}" + (f" / {reason}" if reason else ""),
                )
            return row is not None

    def assign(self, report, rule, actor):
        report_id = report["id"]
        with self.session(write=True) as execute:
            row = execute(
                """INSERT INTO assignments (report_id, responsable, asignado_at,
                       vence_respuesta_at, vence_resolucion_at)
                   VALUES (%s, %s, %s, %s, %s)
                   ON CONFLICT (report_id) DO NOTHING RETURNING report_id""",
                (report_id, rule["responsable"], utc_now(),
                 deadline(report["recibido_at"], rule["respuesta_min"]),
                 deadline(report["recibido_at"], rule["resolucion_min"])),
            ).fetchone()
            if row:
                self.event(execute, report_id, "asignado", actor, rule["responsable"])

    def notify(self, report, actor):
        with self.session(write=True) as execute:
            self.event(
                execute, report["id"], "notificacion", actor,
                f"Nuevo reporte para {report['responsable']}.",
            )

    def advance(self, report_id, action):
        with self.session(write=True) as execute:
            query = "SELECT respondido_at, resuelto_at FROM assignments WHERE report_id = %s"
            row = execute(query + (" FOR UPDATE" if self.url else ""), (report_id,)).fetchone()
            if row is None:
                return False
            if action == "resolver" and row["respondido_at"] is None:
                return False
            column = "respondido_at" if action == "responder" else "resuelto_at"
            if row[column] is None:
                execute(
                    f"UPDATE assignments SET {column} = %s WHERE report_id = %s",
                    (utc_now(), report_id),
                )
                self.event(execute, report_id, action, "operador", "Hito confirmado.")
            return True

    def metrics(self):
        now = utc_now()
        with self.session() as execute:
            return dict(execute(
                """SELECT COUNT(*) AS total,
                       COUNT(a.report_id) AS asignados,
                       COUNT(r.motivo_revision) AS requieren_revision,
                       COUNT(CASE WHEN a.respondido_at <= a.vence_respuesta_at THEN 1 END)
                           AS respuesta_a_tiempo,
                       COUNT(CASE WHEN a.resuelto_at <= a.vence_resolucion_at THEN 1 END)
                           AS resolucion_a_tiempo,
                       COUNT(CASE WHEN a.respondido_at IS NOT NULL
                                       OR a.vence_respuesta_at < %s THEN 1 END)
                           AS respuesta_evaluable,
                       COUNT(CASE WHEN a.resuelto_at IS NOT NULL
                                       OR a.vence_resolucion_at < %s THEN 1 END)
                           AS resolucion_evaluable
                   FROM reports r LEFT JOIN assignments a ON a.report_id = r.id""",
                (now, now),
            ).fetchone())

    def install_audit_triggers(self):
        with self.session(write=True) as execute:
            if self.url:
                execute("""
                    CREATE OR REPLACE FUNCTION soc_audit_immutable() RETURNS trigger
                    LANGUAGE plpgsql AS $$
                    BEGIN
                        RAISE EXCEPTION 'audit_log es inmutable';
                    END $$""")
                execute("""
                    CREATE OR REPLACE FUNCTION soc_audit_change() RETURNS trigger
                    LANGUAGE plpgsql AS $$
                    DECLARE entity text;
                    BEGIN
                        entity := COALESCE(to_jsonb(NEW)->>'id',to_jsonb(NEW)->>'report_id',to_jsonb(NEW)->>'period',
                                           to_jsonb(OLD)->>'id',to_jsonb(OLD)->>'report_id',to_jsonb(OLD)->>'period');
                        INSERT INTO audit_log (id,user_id,role,action,module,ip,occurred_at,phase,entity_id,request_id)
                        VALUES (gen_random_uuid()::text,
                            COALESCE(NULLIF(current_setting('soc.user_id',true),''),'sistema'),
                            COALESCE(NULLIF(current_setting('soc.role',true),''),'sistema'),
                            TG_OP,TG_TABLE_NAME,
                            COALESCE(current_setting('soc.ip',true),''),
                            clock_timestamp(),'change',entity,NULLIF(current_setting('soc.request_id',true),''));
                        IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
                        RETURN NEW;
                    END $$""")
                for operation in ("UPDATE", "DELETE", "TRUNCATE"):
                    name = f"audit_no_{operation.lower()}"
                    execute(f"DROP TRIGGER IF EXISTS {name} ON audit_log")
                    execute(f"CREATE TRIGGER {name} BEFORE {operation} ON audit_log FOR EACH STATEMENT EXECUTE FUNCTION soc_audit_immutable()")
                for table in ("reports", "assignments", "users", "bitacora", "triage_baselines", "triage_measurements", "demo_impact_history"):
                    execute(f"DROP TRIGGER IF EXISTS soc_change ON {table}")
                    execute(f"CREATE TRIGGER soc_change AFTER INSERT OR UPDATE OR DELETE ON {table} FOR EACH ROW EXECUTE FUNCTION soc_audit_change()")
            else:
                for operation in ("UPDATE", "DELETE"):
                    execute(f"""CREATE TRIGGER IF NOT EXISTS audit_no_{operation.lower()}
                        BEFORE {operation} ON audit_log BEGIN
                        SELECT RAISE(ABORT, 'audit_log es inmutable'); END""")

    def log_access(self, actor, action, module, phase, status=None, entity=None):
        actor = actor or {}
        with self.session(write=True) as execute:
            execute("""INSERT INTO audit_log
                (id,user_id,role,action,module,ip,occurred_at,phase,status_code,entity_id,request_id)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (str(uuid4()), actor.get("id", "anonimo"), actor.get("role", "publico"),
                 action, module, actor.get("ip", ""), utc_now(), phase, status, entity, actor.get("request_id")))

    def audit_records(self, limit=200, before=None):
        with self.session() as execute:
            if before:
                row = execute("SELECT occurred_at FROM audit_log WHERE id=%s", (before,)).fetchone()
                if not row:
                    return []
                return [dict(item) for item in execute("""
                    SELECT * FROM audit_log WHERE occurred_at < %s OR (occurred_at = %s AND id < %s)
                    ORDER BY occurred_at DESC,id DESC LIMIT %s""",
                    (row["occurred_at"], row["occurred_at"], before, limit)).fetchall()]
            return [dict(item) for item in execute(
                "SELECT * FROM audit_log ORDER BY occurred_at DESC,id DESC LIMIT %s", (limit,)
            ).fetchall()]

    def all_reports(self):
        with self.session() as execute:
            return [dict(row) for row in execute(REPORTS + " ORDER BY r.recibido_at DESC,r.id").fetchall()]

    def measure_triage(self, report):
        if not report["notificado_at"]:
            return
        def timestamp(value):
            return datetime.fromisoformat(value) if isinstance(value, str) else value
        seconds = max(0, (timestamp(report["notificado_at"]) - timestamp(report["recibido_at"])).total_seconds())
        with self.session(write=True) as execute:
            baseline = execute("SELECT id FROM triage_baselines ORDER BY created_at DESC,id DESC LIMIT 1").fetchone()
            execute("""INSERT INTO triage_measurements
                (report_id,elapsed_seconds,review_seconds,baseline_id,measured_at)
                VALUES (%s,%s,%s,%s,%s) ON CONFLICT (report_id) DO NOTHING""",
                (report["id"], seconds, None if report["motivo_revision"] else 0,
                 baseline["id"] if baseline else None, utc_now()))

    def triage_metrics(self):
        with self.session() as execute:
            baseline = execute("SELECT * FROM triage_baselines ORDER BY created_at DESC,id DESC LIMIT 1").fetchone()
            rows = execute("""SELECT m.*,b.average_seconds,b.is_demo FROM triage_measurements m
                LEFT JOIN triage_baselines b ON b.id=m.baseline_id""").fetchall()
        comparable = [row for row in rows if row["average_seconds"] is not None and row["review_seconds"] is not None]
        seconds_saved = sum(row["average_seconds"] - row["elapsed_seconds"] - row["review_seconds"] for row in comparable)
        return {
            "baseline": dict(baseline) if baseline else None,
            "measured_reports": len(rows), "comparable_reports": len(comparable),
            "pending_review_measurements": sum(row["review_seconds"] is None for row in rows),
            "average_cycle_seconds": sum(row["elapsed_seconds"] for row in rows) / len(rows) if rows else None,
            "estimated_hours_saved": seconds_saved / 3600 if comparable else None,
            "demo_comparisons": sum(bool(row["is_demo"]) for row in comparable),
        }

    def impact_history(self):
        with self.session() as execute:
            rows = [dict(row) for row in execute(
                "SELECT * FROM demo_impact_history ORDER BY period"
            ).fetchall()]
            measured_baselines = execute(
                "SELECT COUNT(*) AS total FROM triage_baselines WHERE is_demo=0"
            ).fetchone()["total"]
        periods = []
        for row in rows:
            count = row["report_count"]
            periods.append({
                "period": row["period"], "source": "demo", "report_count": count,
                "response_on_time": row["response_on_time"],
                "resolution_on_time": row["resolution_on_time"],
                "response_pct": 100 * row["response_on_time"] / count,
                "resolution_pct": 100 * row["resolution_on_time"] / count,
                "manual_seconds_per_case": row["manual_seconds"],
                "automated_seconds_per_case": row["automated_seconds"],
                "review_seconds_per_case": row["review_seconds"],
                "estimated_hours_saved": count * (
                    row["manual_seconds"] - row["automated_seconds"] - row["review_seconds"]
                ) / 3600,
            })
        return {
            "source": "demo", "is_demo": True, "sla_target_pct": 90,
            "periods": periods, "measured_baselines": measured_baselines,
        }

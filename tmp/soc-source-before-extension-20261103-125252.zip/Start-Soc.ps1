﻿[CmdletBinding()]
param([ValidateRange(30,1800)][int]$TimeoutSeconds=360, [switch]$Restart)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$runtime = Join-Path $root '.venv\soc-runtime'
$python = Join-Path $root '.venv\Scripts\python.exe'
$logs = Join-Path $runtime 'startup-logs'
$langflow = Join-Path $env:LOCALAPPDATA 'com.LangflowDesktop\.langflow-venv\Scripts\langflow.exe'
$envFile = Join-Path $runtime 'compose.env'

function Write-Stage([string]$Name,[string]$Message) {
    Write-Host ('[{0:HH:mm:ss}] [{1}] {2}' -f (Get-Date),$Name,$Message)
}
function Test-Http([string]$Url) {
    try {
        $response = $http.GetAsync($Url).GetAwaiter().GetResult()
        try { return $response.IsSuccessStatusCode } finally { $response.Dispose() }
    } catch { return $false }
}
function Start-Native([string]$Name,[string]$Executable,[string]$Arguments) {
    Write-Stage $Name 'Iniciando.'
    $options=@{FilePath=$Executable;ArgumentList=$Arguments;WorkingDirectory=$root;WindowStyle='Hidden';PassThru=$true;RedirectStandardOutput=(Join-Path $logs "$Name.out.log");RedirectStandardError=(Join-Path $logs "$Name.err.log")}
    $process = Start-Process @options
    Set-Content -LiteralPath (Join-Path $runtime "$Name.pid") -Value $process.Id -Encoding ascii
}

Add-Type -AssemblyName System.Net.Http
$handler=[System.Net.Http.HttpClientHandler]::new()
$handler.UseProxy=$false
$http=[System.Net.Http.HttpClient]::new($handler)
$http.Timeout=[TimeSpan]::FromSeconds(3)
Push-Location -LiteralPath $root
try {
    New-Item -ItemType Directory -Force $logs | Out-Null
    Write-Stage 'Docker' 'Comprobando motor.'
    & docker version --format '{{.Server.Version}}' 2>$null
    if ($LASTEXITCODE -ne 0) {
        Start-Process -FilePath 'C:/Program Files/Docker/Docker/Docker Desktop.exe' -WindowStyle Hidden
        $watch=[Diagnostics.Stopwatch]::StartNew()
        do {
            Start-Sleep -Seconds 3
            & docker version --format '{{.Server.Version}}' 2>$null
            if ($LASTEXITCODE -eq 0) { break }
            Write-Stage 'Docker' 'Esperando al motor.'
        } while ($watch.Elapsed.TotalSeconds -lt $TimeoutSeconds)
        if ($LASTEXITCODE -ne 0) { throw 'Docker no pudo iniciar. Revisa Docker Desktop.' }
    }
    if (-not (Test-Path -LiteralPath $envFile)) {
        Write-Stage 'Configuración' 'Preparando contenedores y copias de seguridad.'
        & $python scripts/prepare_containers.py
        if ($LASTEXITCODE -ne 0) { throw 'No se pudo preparar la configuración.' }
    }
    Write-Stage 'Contenedores' 'Levantando PostgreSQL 16, Redis y n8n.'
    & docker compose --env-file $envFile up -d --wait
    if ($LASTEXITCODE -ne 0) { throw 'No se pudieron iniciar los contenedores.' }
    Write-Stage 'Frontend' 'Compilando React y TypeScript.'
    & npm.cmd run build --prefix frontend
    if ($LASTEXITCODE -ne 0) { throw 'Falló la compilación del frontend.' }
    Write-Stage 'Base de datos' 'Verificando esquema y usuarios iniciales.'
    & $python -m backend.manage bootstrap
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo inicializar la base de datos.' }
    $env:FONTCONFIG_FILE=(Join-Path $runtime 'fonts.conf') -replace '\\','/'
    $env:WEASYPRINT_DLL_DIRECTORIES='C:/Program Files/Tesseract-OCR'
    $env:LANGFLOW_CONFIG_DIR=Join-Path $runtime 'langflow'
    $env:LANGFLOW_DATABASE_URL='sqlite:///' + ((Join-Path $runtime 'langflow.sqlite3') -replace '\\','/')
    $env:LANGFLOW_SSRF_ALLOWED_HOSTS='127.0.0.1'
    $env:LANGFLOW_AUTO_LOGIN='true'
    $env:LANGFLOW_DO_NOT_TRACK='true'
    if (-not (Test-Http 'http://127.0.0.1:7861/health')) {
        Start-Native 'Langflow' $langflow 'run --host 127.0.0.1 --port 7861'
    } else {
        $listeners=Get-NetTCPConnection -State Listen -LocalPort 7861 -ErrorAction SilentlyContinue
        foreach ($listener in $listeners) {
            $existing=Get-CimInstance Win32_Process -Filter "ProcessId=$($listener.OwningProcess)"
            if ($existing.CommandLine -like '*langflow*run*--port 7861*') {
                Set-Content -LiteralPath (Join-Path $runtime 'Langflow.pid') -Value $existing.ProcessId -Encoding ascii
            }
        }
    }
    if ($Restart) {
        $pidFile=Join-Path $runtime 'FastAPI.pid'
        if (Test-Path -LiteralPath $pidFile) {
            $savedPid=[int](Get-Content -LiteralPath $pidFile)
            $process=Get-CimInstance Win32_Process -Filter "ProcessId=$savedPid"
            if ($process.CommandLine -like '*uvicorn backend.main:app*') {
                Stop-Process -Id $savedPid
            }
        }
    }
    if (-not (Test-Http 'http://127.0.0.1:8000/health')) {
        Start-Native 'FastAPI' $python '-m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --no-access-log'
    }
    $watch=[Diagnostics.Stopwatch]::StartNew()
    do {
        $apiReady=Test-Http 'http://127.0.0.1:8000/health'
        $flowReady=Test-Http 'http://127.0.0.1:7861/health'
        $routerReady=Test-Http 'http://127.0.0.1:5680/healthz/readiness'
        if ($apiReady -and $flowReady -and $routerReady) { break }
        Write-Stage 'Arranque' "FastAPI=$apiReady Langflow=$flowReady n8n=$routerReady"
        Start-Sleep -Seconds 3
    } while ($watch.Elapsed.TotalSeconds -lt $TimeoutSeconds)
    if (-not ($apiReady -and $flowReady -and $routerReady)) { throw "Servicios pendientes. Revisa $logs" }
    Write-Stage 'SOC' 'Servicios disponibles.'
    Write-Host 'Aplicación    http://127.0.0.1:8000/'
    Write-Host 'API           http://127.0.0.1:8000/docs'
    Write-Host 'Langflow      http://127.0.0.1:7861/'
    Write-Host 'n8n           http://127.0.0.1:5680/'
    Write-Host 'PostgreSQL 16 127.0.0.1:5434 / soc_reports'
    Write-Host "Credenciales  $runtime\access.json"
    Write-Host "Registros     $logs"
} finally {
    Pop-Location
    $http.Dispose()
}

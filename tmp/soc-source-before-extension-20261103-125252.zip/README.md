# SOC Report Router

Plataforma local de clasificación y enrutamiento de reportes. El formulario React envía los datos a FastAPI. Langflow clasifica con Groq y respaldo de Gemini. FastAPI valida y guarda en PostgreSQL antes de invocar n8n. El workflow asigna el equipo y los plazos, y registra el aviso interno.

## Arranque en Windows PowerShell

El entorno preparado utiliza las instalaciones existentes de Python y Langflow. Docker Desktop ejecuta PostgreSQL 16, Redis y n8n. Las dependencias Python permanecen en .venv.

Desde la carpeta del proyecto:

    powershell -ExecutionPolicy Bypass -File .\Start-Soc.ps1

Para aplicar cambios del backend:

    powershell -ExecutionPolicy Bypass -File .\Start-Soc.ps1 -Restart

El comando muestra el progreso, compila React y comprueba la salud de los servicios. Las imágenes de Docker se descargan durante el primer arranque. Si falta node_modules, instala las dependencias con npm ci --prefix frontend. Para instalar las dependencias Python usa .\.venv\Scripts\python.exe -m pip install -r requirements.txt.

| Servicio | Dirección |
| --- | --- |
| Aplicación | http://127.0.0.1:8000/ |
| Documentación de API | http://127.0.0.1:8000/docs |
| Salud del flujo | http://127.0.0.1:8000/health |
| Langflow del proyecto | http://127.0.0.1:7861/ |
| n8n del proyecto en Docker | http://127.0.0.1:5680/ |
| PostgreSQL 16 | 127.0.0.1:5434 |
| Redis autenticado | 127.0.0.1:6380 |

Para detener los procesos y contenedores administrados por el proyecto:

    powershell -ExecutionPolicy Bypass -File .\Stop-Soc.ps1

El frontend lo sirve FastAPI desde frontend/dist. Las fuentes están en frontend/src. Se utilizan React 18, TypeScript, TailwindCSS y Recharts. El backend usa FastAPI, Pydantic y SQLAlchemy con psycopg.

## Usuarios y permisos

Las credenciales iniciales generadas aleatoriamente están en .venv/soc-runtime/access.json. El comando de arranque muestra su ruta. Las contraseñas se guardan con PBKDF2 en la base de datos. El archivo local permite al propietario de este entorno consultar las credenciales iniciales.

| Rol | Permisos |
| --- | --- |
| Administrador | Reportes, cambios de estado, exportación, línea base, usuarios y auditoría |
| Analista | Consulta, reintentos, primera respuesta, resolución y tiempo de revisión |
| Gestor | Consulta de reportes, indicadores, exportación y registro de líneas base |
| Auditor | Lectura de la bitácora de auditoría |

El administrador crea usuarios, cambia roles, restablece contraseñas y desactiva cuentas en Usuarios. Debe permanecer al menos un administrador activo. Cambiar un rol, contraseña o estado invalida los tokens previos de ese usuario.

El acceso web usa JWT con vencimiento y sesiones revocables. Cerrar sesión invalida el token. Redis mantiene sesiones y límites de solicitudes. La interfaz mantiene el token de acceso en memoria y solicita un nuevo inicio de sesión después de recargar la página.

El encabezado histórico X-Operator-Token se conserva para compatibilidad con clientes anteriores si LEGACY_OPERATOR_ENABLED=true. En este entorno integrado está deshabilitado. Los endpoints internos mantienen X-Internal-Token y el webhook de n8n utiliza X-Webhook-Token. Sus secretos son independientes.

## Operación

1. En Nuevo reporte, introduce un título y una descripción con el activo afectado.
2. Espera la confirmación con el ID. La clasificación externa puede tardar.
3. Selecciona Ver en el tablero e inicia sesión.
4. Las columnas Por atender, En atención y Resueltos muestran el avance.
5. El analista registra la primera respuesta cuando ocurre y después la resolución.
6. Ver detalle muestra las fechas, el origen, el motivo de revisión y la bitácora del caso.
7. El gestor puede descargar PDF, Word y Excel desde el tablero. Las exportaciones abarcan todos los reportes, con un máximo de 10000.

El modo oscuro, el idioma y el tema del sistema se seleccionan en la cabecera. El botón Asistente SOC abre un chat flotante en la esquina inferior derecha. FastAPI recibe los mensajes en POST /api/chat, consulta Groq y usa Gemini como respaldo ante errores del proveedor principal. Cada respuesta identifica al proveedor. El historial de la conversación permite preguntas de seguimiento y permanece en memoria mientras la página esté abierta.

Las claves GROQ_API_KEY y GEMINI_API_KEY están en .env y se usan desde el backend. CHAT_GROQ_MODEL y CHAT_GEMINI_MODEL seleccionan los modelos. CHAT_TIMEOUT_SECONDS limita la espera por proveedor y CHAT_LIMIT limita las solicitudes por IP y minuto. El navegador recibe el texto de la respuesta y el nombre del proveedor.

El chat envía al proveedor los mensajes que escribes y el contexto de uso de la aplicación. Sus instrucciones explican los equipos y SLA configurados. Los registros privados de reportes y los secretos del servidor quedan fuera del contexto del chat. La auditoría registra el acceso al endpoint sin guardar el cuerpo de la conversación.

## Clasificación y enrutamiento

El flujo de Langflow sigue en integrations/langflow/cybersecurity_classifier.json y su componente cloud en integrations/langflow/cloud_classifier_model.py. La clasificación devuelve tipo, severidad, activo_afectado y confianza. Una salida inválida, una confianza menor de 0.75 o una posible inyección deriva el reporte a Triaje SOC.

El workflow de n8n está en integrations/n8n/assign_report.json. Los nodos HTTP usan host.docker.internal para llamar a FastAPI desde el contenedor. Asignaciones y plazos proceden de integrations/reglas.json. La notificación es interna y queda en la bandeja.

El Idempotency-Key identifica el envío. El mismo ID con el mismo contenido devuelve el reporte existente. Cambiar el contenido con ese ID produce HTTP 409. Las restricciones de base de datos impiden duplicar la asignación y la notificación inicial.

Cuando n8n falla, el reporte se conserva. El operador puede usar Reintentar enrutamiento. Redis mantiene una cola de reintentos automáticos, y un proceso periódico recupera trabajo pendiente desde PostgreSQL. PostgreSQL sigue siendo la fuente de los pendientes aunque Redis se reinicie.

Los modos SQLite, clasificador demo y enrutador local siguen disponibles mediante DATABASE_URL vacío, REDIS_URL vacío, CLASSIFIER_MODE=demo y ROUTER_MODE=local. Los modos integrados se configuran en .env. La demo usa tablas equivalentes y almacenamiento SQL para sesiones y limitación de solicitudes cuando Redis no está configurado.

## Auditoría

La bitácora de cada reporte conserva sus eventos de negocio. audit_log registra entradas, salidas y accesos rechazados de la API, con identidad, rol, acción, módulo, IP, fecha y resultado HTTP. El cuerpo de las solicitudes y los secretos de autenticación quedan fuera de estos registros.

PostgreSQL tiene triggers para registrar cambios críticos en reportes, asignaciones, usuarios, eventos y mediciones. Otros triggers rechazan UPDATE, DELETE y TRUNCATE sobre audit_log. La protección cubre las operaciones de datos. Un administrador de la base de datos con privilegios para modificar el esquema conserva su autoridad de mantenimiento.

La vista Auditoría admite paginación y está restringida al administrador y al auditor. Cada nueva solicitud auditada tiene un X-Request-ID generado por el servidor. Las fases entry y exit comparten ese identificador, también en rechazos de autenticación, permisos, validación y errores. Los rechazos 401 y 403 conservan además el evento rejected. Los registros anteriores mantienen su contenido y pueden tener el identificador vacío.

## Medición del triaje y SLA

Cada caso notificado registra el tiempo transcurrido desde la recepción hasta el aviso. Un gestor o administrador introduce al menos tres tiempos manuales en segundos para crear una línea base. Se conservan las muestras, el promedio, el autor y la fecha.

La estimación por caso comparable calcula:

    tiempo manual medio - tiempo del ciclo automático - tiempo de revisión humana

Los casos con revisión quedan fuera de la comparación hasta registrar el tiempo humano. Una cifra negativa muestra un incremento del tiempo. El indicador es una estimación basada en tiempos comparables de ciclo, y requiere muestras representativas para evaluar productividad real.

Las muestras creadas para demostración se marcan expresamente y la interfaz las identifica. El script de población genera una línea base sintética.

Los indicadores de SLA incluyen casos con el hito registrado o el plazo vencido. Los pendientes dentro del plazo todavía quedan fuera del cálculo. El tablero muestra los últimos 100 reportes y los indicadores usan todos los registros.

## Histórico de evolución DEMO

La vista Evolución muestra una serie mensual simulada de SLA y tiempo de triaje. Se identifica como DEMO en pantalla y en la respuesta de GET /api/impacto. La meta de SLA del 90 % es ilustrativa. La tabla incluye numeradores, denominadores y tiempos por caso para comprobar el cálculo.

Para preparar los seis meses completos anteriores al mes actual:

    .\.venv\Scripts\python.exe -m backend.manage seed-history

El comando es idempotente por periodo. Los agregados están en demo_impact_history, separados de reports, assignments y las líneas base reales. La fecha de creación refleja la carga actual y el campo period representa el mes simulado. Los eventos de auditoría conservan sus fechas reales de inserción.

En la serie inicial hay 40 casos por mes, una media manual de 15 minutos por caso y una reducción ilustrativa del ciclo automático más revisión desde 13,5 hasta 2,5 minutos. La respuesta a tiempo pasa del 55 % al 95 %, la resolución del 50 % al 92,5 % y el ahorro estimado de 1 a 8,33 horas mensuales. Estas cifras demuestran la visualización y las fórmulas. Acreditar impacto operacional requiere datos medidos comparables y un periodo representativo.

## Pruebas y datos de demostración

Pruebas locales, compilación y pruebas React:

    powershell -ExecutionPolicy Bypass -File .\Test-Soc.ps1

Pruebas adicionales con PostgreSQL, Redis, Langflow, Groq, Gemini y n8n reales. El script evalúa todos los grupos, conserva stdout y stderr en el registro y devuelve un código de salida distinto de cero si falla cualquier grupo:

    powershell -ExecutionPolicy Bypass -File .\Test-Soc.ps1 -Live

Crear 12 reportes identificados como DEMO, repetir sus envíos y registrar varios estados:

    .\.venv\Scripts\python.exe -m backend.manage seed --count 12

Los resultados quedan en .venv/soc-runtime/seed-evidence.json. Las pruebas integradas crean reportes temporales propios y conservan los eventos de auditoría que producen.

## Datos y configuración

El entorno usa PostgreSQL 16 en Docker. La instalación PostgreSQL 18 original y sus archivos permanecen disponibles como origen de la migración. La copia de datos previa está en .venv/soc-runtime/postgres-before-platform.json. La configuración previa está en .venv/soc-runtime/env-before-platform.backup. Contienen información local del proyecto y deben tratarse como privadas.

scripts/migrate_pg16.py copia las tablas originales, verifica sus filas y solo después cambia DATABASE_URL. scripts/prepare_containers.py prepara las credenciales locales y una copia de la base de n8n para el contenedor. El workflow de esa copia utiliza los callbacks hacia FastAPI desde Docker.

.env conserva la configuración del modelo y los secretos de los servicios. compose.env y access.json están dentro de .venv. Los directorios de datos se montan de forma persistente. Stop-Soc.ps1 detiene los servicios sin eliminar esos directorios.

WeasyPrint genera PDF reutilizando las bibliotecas GTK/Pango de Tesseract instaladas en este PC. WEASYPRINT_DLL_DIRECTORIES y FONTCONFIG_FILE se configuran durante el bootstrap.
